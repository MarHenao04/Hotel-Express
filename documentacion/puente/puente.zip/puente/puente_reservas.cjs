// Puente de laboratorio: Google Forms -> n8n local
// Solo deja pasar: POST /webhook/reserva-hotel con JSON.
// Todo lo demas (editor, test URL, otras rutas) recibe 404.
// Escucha solo en 127.0.0.1; el tunel apunta aqui, NUNCA al puerto 5678.

const http = require('http');

const PUERTO_PUENTE = 5681;
const N8N_HOST = '127.0.0.1';
const N8N_PUERTO = 5678;
const RUTA_PERMITIDA = '/webhook/reserva-hotel';
const MAX_BYTES = 10 * 1024;      // 10 KB
const MAX_POR_MINUTO = 30;        // limite simple de peticiones
const TIMEOUT_N8N_MS = 15000;

let ventanaInicio = Date.now();
let contador = 0;

function responder(res, codigo, obj) {
  const cuerpo = JSON.stringify(obj);
  res.writeHead(codigo, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(cuerpo)
  });
  res.end(cuerpo);
}

const servidor = http.createServer((req, res) => {
  const ruta = (req.url || '').split('?')[0];

  // 1. Solo POST a la ruta exacta
  if (req.method !== 'POST' || ruta !== RUTA_PERMITIDA) {
    return responder(res, 404, { ok: false, error: 'NO_ENCONTRADO' });
  }

  // 2. Limite de peticiones por minuto
  const ahora = Date.now();
  if (ahora - ventanaInicio > 60000) { ventanaInicio = ahora; contador = 0; }
  if (++contador > MAX_POR_MINUTO) {
    return responder(res, 429, { ok: false, error: 'DEMASIADAS_PETICIONES' });
  }

  // 3. Debe ser JSON
  const tipo = (req.headers['content-type'] || '').toLowerCase();
  if (!tipo.startsWith('application/json')) {
    return responder(res, 415, { ok: false, error: 'SOLO_JSON' });
  }

  // 4. Leer el cuerpo con limite de tamano
  const trozos = [];
  let total = 0;
  let cortado = false;
  req.on('data', (t) => {
    total += t.length;
    if (total > MAX_BYTES) {
      cortado = true;
      responder(res, 413, { ok: false, error: 'CUERPO_MUY_GRANDE' });
      req.destroy();
      return;
    }
    trozos.push(t);
  });

  req.on('end', () => {
    if (cortado) return;
    const crudo = Buffer.concat(trozos).toString('utf8');

    // 5. Debe ser un objeto JSON valido
    let datos;
    try { datos = JSON.parse(crudo); } catch (e) { datos = null; }
    if (!datos || typeof datos !== 'object' || Array.isArray(datos)) {
      return responder(res, 400, { ok: false, error: 'JSON_INVALIDO' });
    }

    // 6. Reenviar a n8n con solo las cabeceras necesarias
    const cabeceras = {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(crudo)
    };
    if (req.headers['x-api-key']) cabeceras['X-API-Key'] = req.headers['x-api-key'];

    const salida = http.request(
      { host: N8N_HOST, port: N8N_PUERTO, path: RUTA_PERMITIDA, method: 'POST',
        headers: cabeceras, timeout: TIMEOUT_N8N_MS },
      (respN8n) => {
        const partes = [];
        respN8n.on('data', (p) => partes.push(p));
        respN8n.on('end', () => {
          const cuerpo = Buffer.concat(partes);
          res.writeHead(respN8n.statusCode || 502, {
            'Content-Type': respN8n.headers['content-type'] || 'application/json',
            'Content-Length': cuerpo.length
          });
          res.end(cuerpo);
        });
      }
    );
    salida.on('timeout', () => { salida.destroy(); responder(res, 504, { ok: false, error: 'N8N_TARDO_DEMASIADO' }); });
    salida.on('error', () => responder(res, 502, { ok: false, error: 'N8N_NO_RESPONDE' }));
    salida.write(crudo);
    salida.end();
  });
});

servidor.listen(PUERTO_PUENTE, '127.0.0.1', () => {
  console.log('Puente listo en http://127.0.0.1:' + PUERTO_PUENTE);
  console.log('Solo acepta: POST ' + RUTA_PERMITIDA);
});
